package Contoh_GUI_dataBase;

import java.sql.*;
import java.util.ArrayList;

public class Mahasiswa {
    private String nim, prodi, nama, jenisKelamin, tanggalLahir, tempatLahir;
    private String jalan, kelurahan, kecamatan, kota;

    public Mahasiswa(String nim, String prodi, String nama, String jenisKelamin, String tanggalLahir, String tempatLahir,
                     String jalan, String kelurahan, String kecamatan, String kota) {
        this.nim = nim;
        this.prodi = prodi;
        this.nama = nama;
        this.jenisKelamin = jenisKelamin;
        this.tanggalLahir = tanggalLahir;
        this.tempatLahir = tempatLahir;
        this.jalan = jalan;
        this.kelurahan = kelurahan;
        this.kecamatan = kecamatan;
        this.kota = kota;
    }

    public String getNim() {
        return nim;
    }

    public String getProdi() {
        return prodi;
    }

    public String getNama() {
        return nama;
    }

    public String getJenisKelamin() {
        return jenisKelamin;
    }

    public String getTanggalLahir() {
        return tanggalLahir;
    }

    public String getTempatLahir() {
        return tempatLahir;
    }

    public String getJalan() {
        return jalan;
    }

    public String getKelurahan() {
        return kelurahan;
    }

    public String getKecamatan() {
        return kecamatan;
    }

    public String getKota() {
        return kota;
    }

    // Menyimpan data mahasiswa ke database
    public static void saveToDatabase(ArrayList<Mahasiswa> mahasiswaList, String url, String user, String password) throws SQLException {
        Connection conn = DriverManager.getConnection(url, user, password);
        String insertSQL = "INSERT INTO mahasiswa (nim, prodi, nama, jenis_kelamin, tanggal_lahir, tempat_lahir, jalan, kelurahan, kecamatan, kota) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(insertSQL);
        for (Mahasiswa mhs : mahasiswaList) {
            pstmt.setString(1, mhs.getNim());
            pstmt.setString(2, mhs.getProdi());
            pstmt.setString(3, mhs.getNama());
            pstmt.setString(4, mhs.getJenisKelamin());
            pstmt.setDate(5, Date.valueOf(mhs.getTanggalLahir()));
            pstmt.setString(6, mhs.getTempatLahir());
            pstmt.setString(7, mhs.getJalan());
            pstmt.setString(8, mhs.getKelurahan());
            pstmt.setString(9, mhs.getKecamatan());
            pstmt.setString(10, mhs.getKota());
            pstmt.addBatch();
        }
        pstmt.executeBatch();
        conn.close();
    }

    // Membaca data mahasiswa dari database
    public static ArrayList<Mahasiswa> loadFromDatabase(String url, String user, String password) throws SQLException {
        Connection conn = DriverManager.getConnection(url, user, password);
        String querySQL = "SELECT * FROM mahasiswa";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(querySQL);
        ArrayList<Mahasiswa> mahasiswaList = new ArrayList<>();
        while (rs.next()) {
            Mahasiswa mhs = new Mahasiswa(
                    rs.getString("nim"),
                    rs.getString("prodi"),
                    rs.getString("nama"),
                    rs.getString("jenis_kelamin"),
                    rs.getString("tanggal_lahir"),
                    rs.getString("tempat_lahir"),
                    rs.getString("jalan"),
                    rs.getString("kelurahan"),
                    rs.getString("kecamatan"),
                    rs.getString("kota")
            );
            mahasiswaList.add(mhs);
        }
        conn.close();
        return mahasiswaList;
    }
}


